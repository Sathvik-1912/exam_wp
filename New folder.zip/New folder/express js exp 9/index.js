
const express= require('express');
const bodyParser = require('body-parser');
const app=express();
const port=8000;
app.use(bodyParser.urlencoded({extended:true}));
app.get('/',(req,res)=>{
    res.send(`
        <form action="/submit" method="POST">
            <label for="name">Name</label>
            <input type="text" name="name" id="name" required></input>
            <br></br>
            <label for="email">Email</label>
            <input type="email" id="email" required></input>
            <br></br>
            <button type="submit">Submit</button>
        </form>
    `);
});
app.post('/submit',(req,res)=>{
    const {name,email}=req.body;
    res.send(`<h1> thank you ${name}</h1>`);
})
app.listen(port,() =>{
    console.log(`server is running`)
});

